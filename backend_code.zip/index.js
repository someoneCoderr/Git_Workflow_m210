const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

const TABLE_NAME = "CiCd-test";

exports.handler = async (event) => {

    try {

        const method = event.httpMethod;
        const body = event.body ? JSON.parse(event.body) : {};

        // Auto hinzufügen
        if (method === "POST") {

            const params = {
                TableName: TABLE_NAME,
                Item: {
                    Kennzeichen: body.Kennzeichen,
                    Marke: body.Marke,
                    Modell: body.Modell,
                    Besitzer: body.Besitzer,
                    Erstzulassung: body.Erstzulassung
                }
            };

            await dynamo.put(params).promise();

            return response(200, { message: "Auto gespeichert", data: params.Item });
        }

        // Alle Autos anzeigen
        if (method === "GET") {

            const params = {
                TableName: TABLE_NAME
            };

            const result = await dynamo.scan(params).promise();

            return response(200, result.Items);
        }

        // Auto aktualisieren
        if (method === "PUT") {

            const params = {
                TableName: TABLE_NAME,
                Key: {
                    Kennzeichen: body.Kennzeichen
                },
                UpdateExpression: "set Marke = :m, Modell = :mo, Besitzer = :b",
                ExpressionAttributeValues: {
                    ":m": body.Marke,
                    ":mo": body.Modell,
                    ":b": body.Besitzer
                },
                ReturnValues: "UPDATED_NEW"
            };

            const result = await dynamo.update(params).promise();

            return response(200, {
                message: "Auto aktualisiert",
                result: result.Attributes
            });
        }

        // Auto löschen
        if (method === "DELETE") {

            const params = {
                TableName: TABLE_NAME,
                Key: {
                    Kennzeichen: body.Kennzeichen
                }
            };

            await dynamo.delete(params).promise();

            return response(200, {
                message: `Auto mit Kennzeichen ${body.Kennzeichen} gelöscht`
            });
        }

        return response(400, { message: "Ungültige Anfrage" });

    } catch (error) {

        console.error(error);

        return response(500, {
            message: "Serverfehler",
            error: error.message
        });
    }
};

function response(statusCode, body) {
    return {
        statusCode: statusCode,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify(body)
    };
}